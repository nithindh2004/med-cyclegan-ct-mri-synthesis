"""
train.py — Clinical CycleGAN CT↔MRI
Full loss stack per generator step:
  L_G = L_adv  (GAN)
      + L_cyc  (alpha*SSIM + (1-alpha)*L1 + lambda_gdl*GDL + lambda_fft*FFT)
      + L_id   (L1 + lambda_gdl*GDL)         ← GDL on identity too (NEW)
"""
# ── (paste your existing imports, argparse, ETATracker, etc.) ──

# Add to get_args():
#   parser.add_argument("--lambda_edge", type=float, default=5.0)
#   parser.add_argument("--lambda_fft",  type=float, default=2.0)
#   parser.add_argument("--val_every",   type=int,   default=10)


def train(opt):
    # ... (device, AMP, compile setup as before) ...

    # ── Loss Functions ──
    criterion_GAN  = nn.MSELoss()
    criterion_L1   = nn.L1Loss()
    criterion_edge = GradientDifferenceLoss().to(device)
    criterion_fft  = FrequencyDomainLoss(high_freq_weight=2.0).to(device)

    # ... (models, optimisers, schedulers, datasets as before) ...

    for epoch in range(start_epoch, opt.n_epochs):
        G.train(); F.train(); D_A.train(); D_B.train()

        for i, batch in enumerate(train_dl):
            real_CT  = batch["A"].to(device, non_blocking=True)
            real_MRI = batch["B"].to(device, non_blocking=True)

            with torch.no_grad():
                patch_shape = D_B(real_MRI).shape
            real_lbl = torch.ones(patch_shape,  device=device)
            fake_lbl = torch.zeros(patch_shape, device=device)

            # ════════════════════════════════════════════════════
            #  GENERATOR UPDATE
            # ════════════════════════════════════════════════════
            optimizer_G.zero_grad(set_to_none=True)
            with autocast(enabled=use_amp):

                # ── Identity Loss (L1 + GDL) ──────────────────
                id_MRI = G(real_MRI)   # G should map MRI→MRI
                id_CT  = F(real_CT)    # F should map CT→CT
                loss_id = (criterion_L1(id_MRI, real_MRI) +
                           criterion_L1(id_CT,  real_CT)) * opt.lambda_id
                # GDL on identity: keep edges sharp even for same-domain pass
                loss_id_edge = (criterion_edge(id_MRI, real_MRI) +
                                criterion_edge(id_CT,  real_CT)) * opt.lambda_edge * 0.5

                # ── Adversarial Loss ───────────────────────────
                fake_MRI = G(real_CT)
                fake_CT  = F(real_MRI)
                loss_adv = (criterion_GAN(D_B(fake_MRI), real_lbl) +
                            criterion_GAN(D_A(fake_CT),  real_lbl))

                # ── Cycle Consistency ──────────────────────────
                recov_CT  = F(fake_MRI)
                recov_MRI = G(fake_CT)

                # 1. L1
                loss_cyc_L1 = (criterion_L1(recov_CT,  real_CT) +
                               criterion_L1(recov_MRI, real_MRI))

                # 2. SSIM  (minimise 1 − SSIM)
                loss_cyc_ssim = (
                    (1 - ssim(recov_CT,  real_CT,  data_range=2.0, size_average=True)) +
                    (1 - ssim(recov_MRI, real_MRI, data_range=2.0, size_average=True))
                )

                # 3. Gradient Difference (bone boundary sharpness)
                loss_cyc_gdl = (criterion_edge(recov_CT,  real_CT) +
                                criterion_edge(recov_MRI, real_MRI))

                # 4. Frequency Domain (high-freq / bone texture fidelity) ← NEW
                loss_cyc_fft = (criterion_fft(recov_CT,  real_CT) +
                                criterion_fft(recov_MRI, real_MRI))

                # ── Combined Cycle Loss ────────────────────────
                loss_cyc = opt.lambda_cyc * (
                    opt.alpha_ssim        * loss_cyc_ssim +
                    (1 - opt.alpha_ssim)  * loss_cyc_L1  +
                    opt.lambda_edge / opt.lambda_cyc * loss_cyc_gdl +
                    opt.lambda_fft  / opt.lambda_cyc * loss_cyc_fft
                )

                loss_G_total = loss_adv + loss_cyc + loss_id + loss_id_edge

            scaler_G.scale(loss_G_total).backward()
            scaler_G.step(optimizer_G)
            scaler_G.update()

            # ════════════════════════════════════════════════════
            #  DISCRIMINATOR UPDATES  (unchanged from your code)
            # ════════════════════════════════════════════════════
            optimizer_DA.zero_grad(set_to_none=True)
            with autocast(enabled=use_amp):
                fake_CT_stored  = fake_CT_buf.push_and_pop(fake_CT.detach())
                loss_DA = 0.5 * (criterion_GAN(D_A(real_CT),              real_lbl) +
                                 criterion_GAN(D_A(fake_CT_stored.detach()), fake_lbl))
            scaler_DA.scale(loss_DA).backward()
            scaler_DA.step(optimizer_DA)
            scaler_DA.update()

            optimizer_DB.zero_grad(set_to_none=True)
            with autocast(enabled=use_amp):
                fake_MRI_stored = fake_MRI_buf.push_and_pop(fake_MRI.detach())
                loss_DB = 0.5 * (criterion_GAN(D_B(real_MRI),               real_lbl) +
                                 criterion_GAN(D_B(fake_MRI_stored.detach()), fake_lbl))
            scaler_DB.scale(loss_DB).backward()
            scaler_DB.step(optimizer_DB)
            scaler_DB.update()

        # ════════════════════════════════════════════════════
        #  VALIDATION LOOP  (every val_every epochs)
        # ════════════════════════════════════════════════════
        if (epoch + 1) % opt.val_every == 0 and hasattr(opt, 'val_dl'):
            G.eval(); F.eval()
            val_metrics = {"mae_ct": 0., "psnr_ct": 0., "ssim_ct": 0., "n": 0}

            with torch.no_grad():
                for vbatch in opt.val_dl:
                    vreal_CT  = vbatch["A"].to(device)
                    vreal_MRI = vbatch["B"].to(device)
                    vfake_MRI = G(vreal_CT)
                    vrecov_CT = F(vfake_MRI)

                    val_metrics["mae_ct"]  += calculate_mae(vrecov_CT,  vreal_CT)
                    val_metrics["psnr_ct"] += calculate_psnr(vrecov_CT, vreal_CT)
                    val_metrics["ssim_ct"] += calculate_ssim(vrecov_CT, vreal_CT)
                    val_metrics["n"]       += 1

            n = val_metrics["n"]
            print(f"\n  ── Validation (Epoch {epoch+1}) ──")
            print(f"  Cycle-CT  │ MAE: {val_metrics['mae_ct']/n:.4f} "
                  f"│ PSNR: {val_metrics['psnr_ct']/n:.2f} dB "
                  f"│ SSIM: {val_metrics['ssim_ct']/n:.4f}\n")
            G.train(); F.train()

        # ... (checkpointing, LR step, sample saving as before) ...